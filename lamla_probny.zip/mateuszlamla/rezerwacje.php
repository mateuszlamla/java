<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KINO „Za rogiem”</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main>
        <div class="baner"> 
            <img src="baner.jpg" alt="baner">
        </div>
        <div class="lewy">
            <ul>
                <li><a href="index.html">Strona główna</a></li>
            </ul>
            <hr>
            <form action="" method="POST">
                <label for="">Data i godzina seansu</label><br>
                <input type="date" id="data_seansu" name="data_seansu">
                <input type="time" id="godzina_seansu" name="godzina_seansu">
                <input type="submit" value="Pokaż">
            </form>
        </div>
        <div class="prawy">
            <?php
                $link = mysqli_connect('localhost', 'root', '', 'kino');
                mysqli_set_charset($link, "UTF-8");

                if(empty($_POST['data_seansu']) && empty($_POST['godzina_seansu'])){
                    echo "Podaj poprawną datę i godzinę seansu";
                }else{
                    echo "<h3> EKRAN </h3>";
                    $qr1 = "SELECT Miejsce, Rzad FROM rezerwacje WHERE Data = '{$_POST['data_seansu']}' AND Godzina = '{$_POST['godzina_seansu']}'";
                    $result = mysqli_query($link, $qr1);
                    $sala = [];
                    while($row = mysqli_fetch_assoc($result)){
                        for($i=0 ; $i < 15 ; $i++){                            
                            for($j = 0 ; $j < 20 ; $j++){
                                if($row['Rzad'] == $i  && $row['Miejsce'] == $j){
                                    $sala[$i][$j] = 1;
                                }
                            }
                        }
                    }
                    
                    $tabelka = "<table>";
                    for ($i = 0 ; $i < 15 ; $i++){
                        $tabelka .= "<tr>";
                        for($j = 0 ; $j < 20 ; $j++){
                            if(@$sala[$i+1][$j+1] == 1){
                                $tabelka .= "<td style=\"background-color: red;\">" . ($j+1) . "</td>";
                            }else{
                                $tabelka .= "<td style=\"background-color: grey;\">" . ($j+1) . "</td>";
                            }
                        }
                        $tabelka .= "</tr>";
                    }
                    $tabelka .= "</table>";
 
                    echo $tabelka;
                }
                
            ?>
        </div>
        <div class="stopka">
            <h5>Egzamin INF.03 - AUTOR: mateusz lamla</h5>
        </div>
    </main>
</body>
</html>